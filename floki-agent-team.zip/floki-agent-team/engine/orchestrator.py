"""The autonomous loop: ATLAS plans -> writers draft -> VIGIL reviews -> queue.

Runs without any API key: generation is template + knowledge-base driven, so
the team works offline. Every item is persisted so nothing is lost on restart.
"""
from __future__ import annotations

import datetime as dt
import json
import random
import threading
import time
from pathlib import Path

from . import guard
from .agents import (AtlasPlanner, MetraAnalyst, VigilGuard, WRITERS)
from .core import CONFIG, KB, OUT, STATE
from .planner import build_plan, plan_summary

ENGINE_CFG = CONFIG["engine"]
MAX_ITEMS = 600


def now_iso() -> str:
    return dt.datetime.now().replace(microsecond=0).isoformat()


class Orchestrator:
    def __init__(self):
        self.rng = random.Random(20261116)
        self.plan = build_plan(ENGINE_CFG["history_days"])
        self.cursor = 0
        self.seq = 0
        self.items: list[dict] = []
        self.killed: list[dict] = []
        self.log: list[dict] = []
        self.ticks = 0
        self.paused = not ENGINE_CFG["auto_start"]
        self.started_at = now_iso()
        self.agents = {
            "ATLAS": AtlasPlanner(),
            "SKALD": WRITERS["SKALD"],
            "HERALD": WRITERS["HERALD"],
            "VERSE": WRITERS["VERSE"],
            "RUNE": WRITERS["RUNE"],
            "SAGA": WRITERS["SAGA"],
            "VIGIL": VigilGuard(),
            "METRA": MetraAnalyst(),
        }
        self.L = self.log_event
        self._load()

    def _load(self):
        """Resume from disk so a restart never re-generates the same queue."""
        f = STATE / "engine_state.json"
        if not f.exists():
            return
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
            self.items = d.get("items", [])[-MAX_ITEMS:]
            self.log = d.get("log", [])[-120:]
            self.cursor = d.get("cursor", 0)
            self.seq = d.get("seq", len(self.items))
            self.ticks = d.get("ticks", 0)
            self.killed = d.get("killed", [])[-20:]
            self._restore_counters(d.get("vigil_blocked", len(self.killed)))
            self._resumed = bool(self.items)
        except (json.JSONDecodeError, OSError):
            self._resumed = False

    def _restore_counters(self, blocked: int):
        for a in self.agents.values():
            a.tasks_done = sum(1 for i in self.items if i["agent"] == a.codename)
            last = next((i for i in reversed(self.items) if i["agent"] == a.codename), None)
            if last:
                a.last_action = f"#{last['id']} {last['channel']}/{last['format']}"
                a.status = "idle"
        v = self.agents["VIGIL"]
        v.approved = sum(1 for i in self.items if i["status"] == "approved")
        v.edited = sum(1 for i in self.items if i["status"] == "needs_edit")
        v.blocked = blocked
        v.tasks_done = len(self.items)
        m = self.agents["METRA"]
        m.reports = max(1, self.ticks // 12)
        m.tasks_done = m.reports
        m.last_action = f"{m.reports} report(s) written"

    # ------------------------------------------------------------- logging
    def log_event(self, agent: str, msg: str, level: str = "info"):
        self.log.append({"t": now_iso(), "agent": agent, "msg": msg, "level": level})
        if len(self.log) > 400:
            self.log = self.log[-400:]

    # ------------------------------------------------------------ pipeline
    def _next_slots(self, n: int) -> list[dict]:
        out = []
        for _ in range(n):
            if self.cursor >= len(self.plan):
                self.cursor = 0
                self.rng = random.Random(self.rng.randint(0, 10**9))
                self.L("ATLAS", "30-day plan exhausted — rotating back to day 1 with fresh angles.")
            out.append(self.plan[self.cursor])
            self.cursor += 1
        return out

    ROUTING = {
        ("x", "*"): "SKALD",
        ("telegram", "*"): "HERALD",
        ("instagram", "*"): "RUNE",
        ("tiktok", "*"): "VERSE",
        ("youtube", "short_script"): "VERSE",
        ("youtube", "*"): "SAGA",
        ("reddit", "*"): "SAGA",
    }

    def _writer_for(self, channel: str, fmt: str = ""):
        name = self.ROUTING.get((channel, fmt)) or self.ROUTING.get((channel, "*")) or "SKALD"
        return self.agents[name]

    def produce(self, slot: dict) -> dict:
        channel, fmt, pillar = slot["channel"], slot["fmt"], slot["pillar"]
        writer = self._writer_for(channel, fmt)
        writer.status = "writing"
        writer.current_task = f"{channel}/{fmt} · {slot['pillar_theme']}"

        self.L("ATLAS", f"assign {channel}/{fmt} → {writer.codename} (pillar {pillar})")
        draft = writer.draft(channel, fmt, pillar, self.rng)
        if draft.extra.get("spice"):
            kind = "aggressive" if draft.extra["spice"] == "hard" else "hyped"
            self.L(writer.codename, f"{kind} line in draft — VIGIL will judge it", "warn")

        # VIGIL review loop, up to 2 rewrites
        verdict = None
        for attempt in range(3):
            self.agents["VIGIL"].status = "reviewing"
            self.agents["VIGIL"].current_task = f"fact-check #{self.seq + 1} ({channel})"
            verdict = guard.review(draft)
            if verdict["verdict"] != "REJECT":
                break
            self.agents["VIGIL"].blocked += 1
            caught = verdict["hard"][0]["match"] if verdict["hard"] else ""
            self.killed.append({
                "agent": writer.codename, "channel": channel, "format": fmt,
                "phrase": caught, "reason": verdict["notes"][0],
                "draft": draft.body[:190], "t": now_iso(),
            })
            self.killed = self.killed[-20:]
            self.L("VIGIL", f"VETO {writer.codename} draft — '{caught}' ({verdict['hard'][0]['reason'] if verdict['hard'] else verdict['notes'][0]})", "error")
            # send it back to the writer with guardrails on
            self.L("ATLAS", f"returning {channel}/{fmt} to {writer.codename} with safe-mode on", "warn")
            draft = writer.draft(channel, fmt, pillar, self.rng, safe=True)

        body_new = verdict["revised_body"]
        status = {"APPROVED": "approved", "NEEDS_EDIT": "needs_edit", "REJECT": "rejected"}[verdict["verdict"]]
        if status == "approved":
            self.agents["VIGIL"].approved += 1
        elif status == "needs_edit":
            self.agents["VIGIL"].edited += 1
        self.agents["VIGIL"].tasks_done += 1

        self.seq += 1
        item = {
            "id": f"{self.seq:04d}",
            "created_at": now_iso(),
            "scheduled_for": f"{slot['date']} {slot['time_utc']} UTC",
            "channel": channel,
            "format": fmt,
            "pillar": pillar,
            "pillar_theme": slot["pillar_theme"],
            "agent": writer.codename,
            "body": body_new,
            "original_body": draft.body,
            "tags": draft.tags,
            "media_brief": draft.media_brief,
            "sources": draft.sources,
            "facts": draft.proof_ids,
            "compliance": {
                "verdict": verdict["verdict"],
                "score": verdict["score"],
                "notes": verdict["notes"],
                "fixes": verdict["fixes"],
            },
            "status": status,
            "spice": draft.extra.get("spice"),
            "human": None,
            "engagement": self._engagement_projection(channel, fmt, verdict["score"]),
            **{k: v for k, v in (draft.extra or {}).items()},
        }
        self.items.append(item)
        if len(self.items) > MAX_ITEMS:
            self.items = self.items[-MAX_ITEMS:]

        writer.tasks_done += 1
        writer.last_action = f"#{item['id']} {channel}/{fmt}"
        writer.status = "idle"
        writer.current_task = ""
        self.agents["VIGIL"].status = "idle"
        self.agents["VIGIL"].current_task = ""
        self.agents["VIGIL"].last_action = f"#{item['id']} {verdict['verdict']} ({verdict['score']})"

        self.L(writer.codename, f"#{item['id']} {channel}/{fmt} drafted ({len(body_new)} chars)")
        self.L("VIGIL", f"#{item['id']} verdict {verdict['verdict']} · risk score {verdict['score']}/100",
               "ok" if status == "approved" else "warn")
        return item

    def _engagement_projection(self, channel: str, fmt: str, score: int) -> int:
        """METRA's heuristic reach estimate. Projection, not real analytics."""
        base = {"x": 100, "telegram": 70, "instagram": 80, "tiktok": 140,
                "youtube": 90, "reddit": 120}.get(channel, 80)
        fmt_mult = {"thread": 1.5, "short_script": 1.4, "carousel": 1.2, "quiz": 1.3,
                    "poll_brief": 1.25, "discussion_post": 1.3}.get(fmt, 1.0)
        return round(base * fmt_mult * (0.6 + score / 100) * self.rng.uniform(0.85, 1.25))

    def tick(self, n: int | None = None) -> list[dict]:
        n = n or ENGINE_CFG["items_per_tick"]
        made = []
        for slot in self._next_slots(n):
            try:
                made.append(self.produce(slot))
            except Exception as exc:  # keep the loop alive no matter what
                self.L("ATLAS", f"pipeline error: {exc}", "error")
        self.ticks += 1
        self.agents["ATLAS"].cycles = self.ticks
        self.agents["ATLAS"].tasks_done = self.ticks
        self.agents["ATLAS"].last_action = f"cycle {self.ticks} · plan {self.cursor}/{len(self.plan)}"

        if self.ticks % 12 == 0:
            self._metra_report()
        if self.ticks % 20 == 0:
            self.save()

    def _metra_report(self):
        m = self.agents["METRA"]
        m.status = "analysing"
        stats = self.metrics()
        best = stats.get("best_channel", "-")
        self.L("METRA", f"report: {stats['total']} items · approval {stats['approval_rate']}% · "
                        f"top projected channel {best}", "ok")
        m.reports += 1
        m.tasks_done = m.reports
        m.last_action = f"report #{m.reports} · approval {stats['approval_rate']}%"
        m.status = "idle"
        self.write_outputs()

    # ------------------------------------------------------------- metrics
    def metrics(self) -> dict:
        total = len(self.items)
        if not total:
            return {"total": 0, "approval_rate": 100, "avg_score": 100, "by_channel": {},
                    "by_pillar": {}, "rejected": 0, "edited": 0, "projected_reach": 0}
        approved = sum(1 for i in self.items if i["status"] == "approved")
        edited = sum(1 for i in self.items if i["status"] == "needs_edit")
        rejected = sum(1 for i in self.items if i["status"] == "rejected")
        by_channel: dict[str, int] = {}
        pillar_count: dict[str, int] = {}
        chan_reach: dict[str, int] = {}
        for i in self.items:
            by_channel[i["channel"]] = by_channel.get(i["channel"], 0) + 1
            pillar_count[i["pillar_theme"]] = pillar_count.get(i["pillar_theme"], 0) + 1
            chan_reach[i["channel"]] = chan_reach.get(i["channel"], 0) + i["engagement"]
        best_channel = max(chan_reach, key=chan_reach.get) if chan_reach else "-"
        return {
            "total": total,
            "approved": approved,
            "edited": edited,
            "rejected": rejected,
            "approval_rate": round(100 * (approved + edited) / total, 1),
            "clean_rate": round(100 * approved / total, 1),
            "avg_score": round(sum(i["compliance"]["score"] for i in self.items) / total, 1),
            "by_channel": by_channel,
            "by_pillar": pillar_count,
            "projected_reach": sum(i["engagement"] for i in self.items),
            "best_channel": best_channel,
            "pending_human": sum(1 for i in self.items if i["human"] is None),
        }

    def state_payload(self, limit: int = 60) -> dict:
        agents = [a.snapshot() for a in self.agents.values()]
        for a in agents:
            if a["codename"] == "VIGIL":
                v = self.agents["VIGIL"]
                a["counters"] = {"approved": v.approved, "edited": v.edited, "blocked": v.blocked}
        return {
            "status": {
                "paused": self.paused,
                "ticks": self.ticks,
                "started_at": self.started_at,
                "cursor": self.cursor,
                "plan_slots": len(self.plan),
                "now": now_iso(),
                "tick_seconds": ENGINE_CFG["tick_seconds"],
            },
            "campaign": CONFIG["campaign"],
            "agents": agents,
            "items": list(reversed(self.items))[:limit],
            "log": list(reversed(self.log))[:40],
            "metrics": self.metrics(),
            "plan": plan_summary(self.plan),
            "killed": list(reversed(self.killed))[:6],
            "kb": guard.facts_digest(),
            "compliance_rules": {
                "hard": [{"id": r["id"], "reason": r["reason"]} for r in __import__(
                    "json").load(open(Path(__file__).resolve().parent.parent / "data" / "compliance.json"))["hard_block"]],
            },
        }

    # ------------------------------------------------------------- human loop
    def set_human(self, item_id: str, action: str) -> bool:
        for i in self.items:
            if i["id"] == item_id:
                i["human"] = action
                self.L("YOU", f"#{item_id} marked {action}", "ok")
                self.write_outputs()
                return True
        return False

    # ------------------------------------------------------------- outputs
    def save(self):
        STATE.mkdir(exist_ok=True, parents=True)
        payload = {"ticks": self.ticks, "cursor": self.cursor, "seq": self.seq,
                   "items": self.items, "log": self.log[-120:],
                   "killed": self.killed[-20:],
                   "vigil_blocked": self.agents["VIGIL"].blocked}
        with open(STATE / "engine_state.json", "w", encoding="utf-8") as fh:
            json.dump(payload, fh, ensure_ascii=False, indent=1)

    def write_outputs(self):
        OUT.mkdir(exist_ok=True, parents=True)
        with open(OUT / "queue.jsonl", "w", encoding="utf-8") as fh:
            for i in self.items:
                fh.write(json.dumps(i, ensure_ascii=False) + "\n")
        self._write_calendar()
        self._write_report()

    def _write_calendar(self):
        lines = ["# FLOKI agent team — content calendar (auto-generated)", "",
                 f"_Generated {now_iso()} · {len(self.items)} items · "
                 f"{len(self.plan)} planned slots over {ENGINE_CFG['history_days']} days_", ""]
        by_day: dict[str, list[dict]] = {}
        for i in self.items:
            by_day.setdefault(i["scheduled_for"][:10], []).append(i)
        for day in sorted(by_day):
            lines.append(f"## {day}")
            for i in sorted(by_day[day], key=lambda x: x["scheduled_for"]):
                badge = {"approved": "✅", "needs_edit": "✏️", "rejected": "⛔"}[i["status"]]
                lines.append(f"- `{i['scheduled_for'][11:]}` {badge} **{i['channel']}/{i['format']}** "
                             f"({i['pillar']}) by {i['agent']} — {i['body'].splitlines()[0][:110]}")
            lines.append("")
        (OUT / "content_calendar.md").write_text("\n".join(lines), encoding="utf-8")

    def _write_report(self):
        m = self.metrics()
        top = sorted(self.items, key=lambda x: x["engagement"], reverse=True)[:5]
        lines = [
            "# METRA weekly report — FLOKI agent team", "",
            f"_{now_iso()} · cycle {self.ticks} · projection model, not live analytics_", "",
            "## Funnel", "",
            f"- items produced: **{m['total']}**",
            f"- approved clean: **{m['approved']}** ({m['clean_rate']}%)",
            f"- auto-repaired by VIGIL: **{m['edited']}**",
            f"- rejected: **{m['rejected']}**",
            f"- average compliance score: **{m['avg_score']}/100**",
            f"- projected incremental reach: **{m['projected_reach']:,}**", "",
            "## Channel mix", "",
        ]
        for ch, c in sorted(m["by_channel"].items(), key=lambda kv: -kv[1]):
            lines.append(f"- {ch}: {c} items")
        lines += ["", "## Pillar balance", ""]
        for p, c in sorted(m["by_pillar"].items(), key=lambda kv: -kv[1]):
            lines.append(f"- {p}: {c}")
        lines += ["", "## Top 5 projected performers", ""]
        for i in top:
            lines.append(f"1. **#{i['id']} {i['channel']}/{i['format']}** — projected {i['engagement']} · "
                         f"{i['body'].splitlines()[0][:100]}")
        lines += ["", "## Learnings for ATLAS", "",
                  f"- Best projected channel: **{m['best_channel']}** — shift one slot/day toward it.",
                  f"- Auto-repair rate {round(100*m['edited']/max(1,m['total']),1)}% — "
                  "keep VIGIL's soft-flag list tight or writers start self-censoring.",
                  "- Rotate TRANSPARENCY pillar twice weekly: highest save/share propensity in tests, "
                  "lowest conversion to follows.", ""]
        (OUT / "report.md").write_text("\n".join(lines), encoding="utf-8")

    def export_csv(self) -> str:
        import csv, io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["id", "scheduled_for", "channel", "format", "pillar", "agent", "status",
                    "compliance_verdict", "risk_score", "projected_reach", "body"])
        for i in self.items:
            w.writerow([i["id"], i["scheduled_for"], i["channel"], i["format"], i["pillar"],
                        i["agent"], i["status"], i["compliance"]["verdict"],
                        i["compliance"]["score"], i["engagement"], i["body"]])
        return buf.getvalue()


ENGINE = Orchestrator()


def _loop():
    while True:
        interval = ENGINE_CFG["tick_seconds"]
        time.sleep(interval)
        if ENGINE.paused:
            continue
        try:
            ENGINE.tick()
        except Exception as exc:
            ENGINE.L("ATLAS", f"tick failed: {exc}", "error")


def seed():
    n = ENGINE_CFG.get("seed_on_start", 20)
    if getattr(ENGINE, "_resumed", False):
        ENGINE.log_event("ATLAS", f"resumed from disk: {len(ENGINE.items)} items, "
                                  f"cycle {ENGINE.ticks}, plan cursor {ENGINE.cursor}", "ok")
        ENGINE.write_outputs()
        return
    ENGINE.log_event("ATLAS", f"boot: plan built with {len(ENGINE.plan)} slots across "
                              f"{ENGINE_CFG['history_days']} days")
    ENGINE.log_event("VIGIL", f"rules loaded: {guard.facts_digest()['hard_rules']} hard blocks, "
                              f"{guard.facts_digest()['soft_rules']} soft flags")
    for _ in range(n):
        ENGINE.tick()
    ENGINE.write_outputs()
    ENGINE.save()
    ENGINE.log_event("ATLAS", f"queue seeded with {len(ENGINE.items)} items — autonomous loop armed", "ok")


def start_background():
    seed()
    t = threading.Thread(target=_loop, daemon=True, name="agent-loop")
    t.start()
    return t


if __name__ == "__main__":
    start_background()
    while True:
        time.sleep(3600)
