"""Core helpers shared by all agents: config, knowledge base, text utilities."""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "outputs"
STATE = ROOT / "state"


def load_json(path: Path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


CONFIG = load_json(ROOT / "config.json")
COMPLIANCE = load_json(DATA / "compliance.json")


class KnowledgeBase:
    """Every claim an agent may make must come from here."""

    def __init__(self, path: Path | None = None):
        raw = load_json(path or (DATA / "floki_facts.json"))
        self.meta = raw["meta"]
        self.facts = {f["id"]: f for f in raw["facts"]}

    def get(self, fact_id: str) -> dict:
        return self.facts[fact_id]

    def statement(self, fact_id: str) -> str:
        return self.facts[fact_id]["statement"]

    def publishable(self, fact_id: str) -> bool:
        f = self.facts.get(fact_id)
        return bool(f and f.get("publish_safe") and f.get("confidence") in ("high", "medium"))

    def pick(self, ids: list[str], rng: random.Random, pool_size: int = 2) -> list[str]:
        safe = [i for i in ids if self.publishable(i)]
        if not safe:
            return []
        rng.shuffle(safe)
        return safe[:pool_size]

    def sources(self, ids: list[str]) -> list[dict]:
        seen, out = set(), []
        for i in ids:
            f = self.facts.get(i)
            if not f:
                continue
            s = f["source"]
            if s["url"] in seen:
                continue
            seen.add(s["url"])
            out.append({"fact": i, "name": s["name"], "url": s["url"]})
        return out

    def search(self, tags: list[str], publishable_only: bool = True) -> list[str]:
        ids = []
        for fid, f in self.facts.items():
            if publishable_only and not self.publishable(fid):
                continue
            if set(tags) & set(f.get("tags", [])):
                ids.append(fid)
        return sorted(ids)


KB = KnowledgeBase()


# ---------------------------------------------------------------- text utils
EMOJI = {
    "viking": ["⚔️", "🛡️", "🔥", "🪓"],
    "game": ["🎮", "🕹️", "🏆", "🗺️"],
    "defi": ["🔒", "📜", "🧾", "⚙️"],
    "learn": ["🧠", "📚", "🎓", "🔍"],
    "community": ["🐕", "🤝", "🌊", "🫂"],
    "pay": ["💳", "🛒", "🏪", "📦"],
    "warn": ["⚠️", "🚨", "🧯", "🛑"],
    "spark": ["✦", "→", "//", "·"],
}

HASHTAG_SETS = {
    "utility": ["#FLOKI", "#UtilityMemecoin", "#Crypto"],
    "gaming": ["#FLOKI", "#Valhalla", "#Web3Gaming"],
    "defi": ["#FLOKI", "#FlokiFi", "#DeFi"],
    "education": ["#FLOKI", "#DYOR", "#Crypto"],
    "community": ["#FLOKI", "#FlokiVikings", "#Memecoin"],
    "commerce": ["#FLOKI", "#Crypto", "#Web3"],
    "transparency": ["#FLOKI", "#DYOR", "#Crypto"],
    "tokenfi": ["#FLOKI", "#TokenFi", "#RWA"],
}


def emoji(kind: str, rng: random.Random) -> str:
    return rng.choice(EMOJI.get(kind, EMOJI["spark"]))


def fit(text: str, limit: int) -> str:
    """Trim to limit on a word boundary without breaking markdown/links."""
    text = " ".join(text.split())
    if len(text) <= limit:
        return text
    cut = text[: limit - 1]
    if " " in cut:
        cut = cut[: cut.rfind(" ")]
    return cut.rstrip(" ,;:—-") + "…"


def tags_for(pillar_id: str) -> list[str]:
    key = {
        "UTILITY_PROOF": "utility",
        "GAMING": "gaming",
        "DEFI_TRUST": "defi",
        "EDUCATION": "education",
        "COMMUNITY": "community",
        "COMMERCE_PAYMENTS": "commerce",
        "TRANSPARENCY": "transparency",
    }.get(pillar_id, "utility")
    return HASHTAG_SETS[key]


@dataclass
class Draft:
    """Structured content before channel rendering + compliance review."""

    agent: str
    channel: str
    fmt: str
    pillar: str
    hook: str
    points: list[str] = field(default_factory=list)
    proof_ids: list[str] = field(default_factory=list)
    cta: str = ""
    tags: list[str] = field(default_factory=list)
    media_brief: str = ""
    risk_note: str = ""
    body: str = ""          # filled by renderer
    sources: list[dict] = field(default_factory=list)
    extra: dict = field(default_factory=dict)
