"""ATLAS planning layer: turns cadence config into a concrete 30-day slot plan."""
from __future__ import annotations

import datetime as dt
import itertools

from .core import CONFIG

WEEKDAY_KEYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

# Weekly channel rhythm (weekday index, Mon=0). Keeps cadence believable
# instead of blasting every channel every day.
WEEKLY = {
    "x": [0, 1, 2, 3, 4, 5, 6],          # daily, multiple slots
    "telegram": [0, 1, 2, 3, 4, 5, 6],   # daily, multiple slots
    "instagram": [0, 2, 4, 5],           # Mon / Wed / Fri / Sat
    "tiktok": [0, 1, 2, 3, 4, 6],        # 6x
    "youtube": [1, 4],                   # Tue / Fri
    "reddit": [2, 5],                    # Wed / Sat
}

SLOT_TIMES = {
    "x": ["08:30", "12:00", "17:30"],
    "telegram": ["09:00", "15:00"],
    "instagram": ["11:00"],
    "tiktok": ["14:00"],
    "youtube": ["16:00"],
    "reddit": ["13:00"],
}

FORMATS = {ch: c["formats"] for ch, c in CONFIG["channels"].items()}


def build_plan(days: int = 30, start: dt.date | None = None) -> list[dict]:
    """Return a flat, chronologically sorted list of content slots."""
    start = start or dt.date.today()
    plan: list[dict] = []
    cycles = {ch: itertools.cycle(FORMATS[ch]) for ch in FORMATS}

    for offset in range(days):
        day = start + dt.timedelta(days=offset)
        wd = day.weekday()
        pillar = CONFIG["pillars"][WEEKDAY_KEYS[wd]]
        for channel, weekdays in WEEKLY.items():
            if wd not in weekdays:
                continue
            for t in SLOT_TIMES[channel]:
                plan.append({
                    "date": day.isoformat(),
                    "time_utc": t,
                    "channel": channel,
                    "fmt": next(cycles[channel]),
                    "pillar": pillar["id"],
                    "pillar_theme": pillar["theme"],
                    "weekday": WEEKDAY_KEYS[wd],
                })
    plan.sort(key=lambda s: (s["date"], s["time_utc"]))
    return plan


def plan_summary(plan: list[dict]) -> dict:
    per_channel: dict[str, int] = {}
    for s in plan:
        per_channel[s["channel"]] = per_channel.get(s["channel"], 0) + 1
    return {
        "days": len({s["date"] for s in plan}),
        "slots": len(plan),
        "per_channel": per_channel,
        "first": plan[0] if plan else None,
        "last": plan[-1] if plan else None,
    }
