"""VIGIL — Compliance & Fact-Guard agent logic.

Veto power: nothing enters the publishing queue without a verdict here.
"""
from __future__ import annotations

import re

from .core import COMPLIANCE, KB

HARD = [(r["id"], re.compile(r["pattern"], re.I), r) for r in COMPLIANCE["hard_block"]]
SOFT = [(r["id"], re.compile(r["pattern"], re.I), r) for r in COMPLIANCE["soft_flag"]]
LIMITS = COMPLIANCE["channel_limits"]
FORBIDDEN_TAGS = {t.lower() for t in COMPLIANCE["forbidden_hashtags"]}
ESCAPE = COMPLIANCE["required_disclosure"]

SOFT_SWAPS = [
    # ordered: phrase-level repairs first so the sentence still reads naturally
    (re.compile(r"the most undervalued memecoin out there", re.I), "a memecoin a lot of people overlook"),
    (re.compile(r"cheap right now, if you ask me", re.I), "worth a proper look, if you ask me"),
    (re.compile(r"arguably the best memecoin of 2026", re.I), "one of the most active builders of 2026"),
    (re.compile(r"coming very soon, mark my words", re.I), "on the roadmap, with no confirmed date"),
    (re.compile(r"\bundervalued\b", re.I), "under-followed"),
    (re.compile(r"\bcheap\b|\bdiscount\b|\bmurah\b", re.I), "early in its build-out"),
    (re.compile(r"\bbest coin\b|\btop pick\b|\bnumber one\b|\bterbaik\b", re.I), "one of the most active builders"),
    (re.compile(r"\bsoon\b|\bcoming very soon\b|\bsegera hadir\b", re.I), "per the team's roadmap, with no confirmed date"),
    (re.compile(r"\bwill rise\b|\bdefinitely\b|\bcertainly\b|\bpasti naik\b", re.I), "could, depending on execution"),
    (re.compile(r"\bmoon\b", re.I), "run"),
]


INTERNAL_LINE = re.compile(r"(?im)^\s*(do not say|nfa|disclosure|answer key)\s*[:\-].*$")


def strip_internal(text: str) -> str:
    """Remove disclosure text and production notes before scanning.

    The required disclaimer contains the phrase 'financial advice' and the
    TikTok brief contains the words it forbids — scanning those would create
    false positives against our own guardrails.
    """
    clean = INTERNAL_LINE.sub("", text)
    for phrase in ESCAPE.values():
        clean = clean.replace(phrase, " ")
    return clean


def _scan(text: str, table):
    text = strip_internal(text)
    hits = []
    for rid, rx, rule in table:
        for m in rx.finditer(text):
            hits.append({
                "id": rid,
                "match": m.group(0),
                "reason": rule["reason"],
                "severity": rule.get("severity", 8),
                "at": m.start(),
                "fix": rule.get("fix", ""),
            })
    return hits


def _apply_soft_fixes(text: str) -> tuple[str, list[str]]:
    notes = []
    for rx, repl in SOFT_SWAPS:
        if rx.search(text):
            notes.append(f"rephrased /{rx.pattern}/ -> '{repl}'")
            text = rx.sub(repl, text)
    return text, notes


def _ensure_disclosure(body: str, channel: str, extra_lines: list[str]) -> tuple[str, bool]:
    pieces = [body.rstrip()]
    added = False
    low = body.lower()
    if ESCAPE["every_post"].lower() not in low:
        pieces.append(ESCAPE["every_post"])
        added = True
    for line in extra_lines:
        if line.lower() not in low:
            pieces.append(line)
            added = True
    joiner = "\n\n" if channel in ("telegram", "instagram", "reddit", "youtube") else " "
    out = joiner.join(pieces)
    limit = LIMITS.get(channel, LIMITS["telegram"])["chars"]
    if len(out) > limit:
        out = out[:limit]
    return out, added


def review(draft) -> dict:
    """Return a verdict dict for a rendered draft."""
    body = draft.body or ""
    hard = _scan(body, HARD)
    soft = _scan(body, SOFT)

    # hashtag hygiene
    bad_tags = [t for t in draft.tags if t.lower() in FORBIDDEN_TAGS]
    tag_budget = LIMITS.get(draft.channel, LIMITS["telegram"])["hashtags_max"]
    over_tags = max(0, len(draft.tags) - tag_budget)

    # fact provenance: every claim must point at a fact id
    provenance_ok = bool(draft.proof_ids)
    unpublished = [f for f in draft.proof_ids if not KB.publishable(f)]

    score = 100
    notes: list[str] = []
    severity_total = sum(h["severity"] for h in hard)
    score -= min(75, severity_total // 2 if severity_total else 0)
    score -= 7 * len(soft)
    score -= 5 * over_tags + 20 * len(bad_tags)
    if not provenance_ok:
        score -= 25
    if unpublished:
        score -= 30
    score = max(0, min(100, score))

    fixes_applied = []
    revised = body
    if soft:
        revised, fixes = _apply_soft_fixes(revised)
        fixes_applied += fixes
        soft = _scan(revised, SOFT)

    extra_lines = []
    if "security" in (draft.risk_note or "") or any(re.search(r"\bbot\b", revised, re.I) for _ in [0]):
        if re.search(r"\b(bot|exploit)\b", revised, re.I):
            extra_lines.append(ESCAPE["when_mentioning_bot_incident"])
    revised, disclosure_added = _ensure_disclosure(revised, draft.channel, extra_lines)
    if disclosure_added:
        notes.append("disclosure appended")
        score = min(100, score + 2)

    if hard:
        verdict = "REJECT"
        notes.insert(0, f"blocked claim: {hard[0]['reason']} ('{hard[0]['match']}')")
    elif not provenance_ok or unpublished:
        verdict = "REJECT"
        notes.insert(0, "unverified or unpublished fact used — no source in facts base")
    elif fixes_applied or soft or over_tags or bad_tags:
        verdict = "NEEDS_EDIT"
        if fixes_applied:
            notes.insert(0, f"{len(fixes_applied)} risky phrase(s) auto-rephrased")
    else:
        verdict = "APPROVED"

    return {
        "verdict": verdict,
        "score": score,
        "hard": hard,
        "soft": soft,
        "bad_tags": bad_tags,
        "over_tags": over_tags,
        "notes": notes,
        "fixes": fixes_applied,
        "revised_body": revised,
        "hash_ok": not bad_tags and not over_tags,
    }


def facts_digest() -> dict:
    """Quick health numbers for the dashboard."""
    total = len(KB.facts)
    pub = sum(1 for fid in KB.facts if KB.publishable(fid))
    return {
        "facts_total": total,
        "facts_publishable": pub,
        "facts_blocked": total - pub,
        "hard_rules": len(HARD),
        "soft_rules": len(SOFT),
    }
