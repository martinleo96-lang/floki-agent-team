"""HTTP layer: serves the dashboard + JSON API. Dependency-free (stdlib only)."""
from __future__ import annotations

import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

from .core import CONFIG, OUT, ROOT
from .orchestrator import ENGINE, start_background

WEB = ROOT / "web"
PORT = CONFIG["engine"]["port"]


class Handler(BaseHTTPRequestHandler):
    server_version = "FlokiAgentTeam/1.0"

    def log_message(self, fmt, *args):  # quieter logs
        return

    # ------------------------------------------------------------------ utils
    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code: int = 200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def _text(self, text: str, ctype: str = "text/plain; charset=utf-8", code: int = 200):
        self._send(code, text.encode(), ctype)

    # -------------------------------------------------------------------- GET
    def do_GET(self):
        path = urlparse(self.path).path
        qs = parse_qs(urlparse(self.path).query)
        if path in ("/", "/index.html", "/dashboard"):
            f = WEB / "index.html"
            if not f.exists():
                return self._text("dashboard missing", code=500)
            return self._send(200, f.read_bytes(), "text/html; charset=utf-8")
        if path == "/api/state":
            limit = int(qs.get("limit", ["60"])[0])
            return self._json(ENGINE.state_payload(limit=limit))
        if path == "/api/file":
            name = qs.get("name", ["calendar"])[0]
            mapping = {
                "calendar": OUT / "content_calendar.md",
                "report": OUT / "report.md",
                "queue": OUT / "queue.jsonl",
            }
            f = mapping.get(name)
            if not f or not f.exists():
                return self._text("not found", code=404)
            return self._text(f.read_text(encoding="utf-8"))
        if path == "/api/feed.json":
            # Universal outbound hook: let Zapier / Make / n8n poll approved copy
            # and publish it to X, Telegram, Instagram, TikTok, YouTube, Reddit.
            only_new = qs.get("new", ["1"])[0] == "1"
            limit = int(qs.get("limit", ["25"])[0])
            feed = [i for i in ENGINE.items
                    if i["status"] != "rejected"
                    and (i["human"] in ("approved", None) if only_new else True)
                    and not i.get("posted")]
            return self._json({"count": len(feed[:limit]), "next_poll_seconds": 60,
                               "items": feed[:limit]})
        if path == "/api/export.csv":
            return self._text(ENGINE.export_csv(), "text/csv; charset=utf-8")
        if path.startswith("/api/item/"):
            item_id = path.rsplit("/", 1)[-1]
            for i in ENGINE.items:
                if i["id"] == item_id:
                    return self._json(i)
            return self._json({"error": "not found"}, 404)
        # static
        rel = path.lstrip("/")
        f = (WEB / rel).resolve()
        if f.is_file() and WEB in f.parents:
            ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
            return self._send(200, f.read_bytes(), ctype)
        return self._text("not found", code=404)

    # ------------------------------------------------------------------- POST
    def do_POST(self):
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(raw or b"{}")
        except json.JSONDecodeError:
            payload = {}

        if path == "/api/cycle":
            n = int(payload.get("n", 3))
            ENGINE.log_event("YOU", f"manual trigger: run {n} slot(s)", "ok")
            ENGINE.tick(n)
            ENGINE.save()
            return self._json({"ok": True, "items": len(ENGINE.items)})
        if path == "/api/pause":
            ENGINE.paused = True
            ENGINE.log_event("YOU", "autonomous loop paused", "warn")
            return self._json({"ok": True, "paused": True})
        if path == "/api/resume":
            ENGINE.paused = False
            ENGINE.log_event("YOU", "autonomous loop resumed", "ok")
            return self._json({"ok": True, "paused": False})
        if path == "/api/verdict":
            item_id = str(payload.get("id", ""))
            action = payload.get("action", "approved")
            if action not in ("approved", "rejected", "hold"):
                return self._json({"ok": False, "error": "bad action"}, 400)
            ok = ENGINE.set_human(item_id, action)
            return self._json({"ok": ok})
        if path == "/api/mark-posted":
            item_id = str(payload.get("id", ""))
            for i in ENGINE.items:
                if i["id"] == item_id:
                    i["posted"] = {"at": payload.get("at", ""), "url": payload.get("url", "")}
                    ENGINE.log_event("METRA", f"#{item_id} confirmed published"
                                     + (f" → {payload.get('url')}" if payload.get("url") else ""), "ok")
                    return self._json({"ok": True})
            return self._json({"ok": False, "error": "unknown id"}, 404)
        if path == "/api/export":
            ENGINE.write_outputs()
            ENGINE.save()
            ENGINE.log_event("METRA", "outputs written: queue.jsonl, calendar.md, report.md", "ok")
            return self._json({"ok": True})
        return self._json({"ok": False, "error": "unknown endpoint"}, 404)


def main():
    start_background()
    httpd = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"[agent-team] dashboard on http://0.0.0.0:{PORT}  ({len(ENGINE.items)} items queued)", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
