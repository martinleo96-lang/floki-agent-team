"""The agent team: roles, draft generation and channel rendering."""
from __future__ import annotations

import random

from .content_bank import PILLARS, POLLS, QUIZZES
from .core import CONFIG, KB, Draft, emoji, fit, tags_for

NFA = "Not financial advice. DYOR."


def _tags(pillar_id: str, rng: random.Random, n: int = 2) -> list[str]:
    t = list(tags_for(pillar_id))
    rng.shuffle(t)
    return t[:n]


def _pick_pillar_context(pillar_id: str, rng: random.Random):
    p = PILLARS[pillar_id]
    hook = rng.choice(p["hooks"])
    angle = list(rng.choice(p["angles"]))
    cta = rng.choice(p["ctas"])
    media = rng.choice(p["media"])
    return p, hook, angle, cta, media


def _proof_ids(pillar_id: str, rng: random.Random) -> list[str]:
    weekday_map = {v["id"]: v["facts"] for v in CONFIG["pillars"].values()}
    ids = weekday_map.get(pillar_id, [])
    return KB.pick(ids, rng, pool_size=3)


# --------------------------------------------------------------- renderers
NL = "\n"


def render_x_post(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    point = min(angle, key=len)
    tags = " ".join(d.tags)
    body = f"{hook}{NL}{NL}{point}{NL}{NL}{cta} {tags}"
    d.body = fit(body, 242)
    d.media_brief = "" if rng.random() > 0.4 else media
    return d


def render_x_thread(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    t = [
        f"1/ {hook}",
        f"2/ Here's what's actually checkable, product by product.",
        f"3/ {angle[0]}",
        f"4/ {angle[1] if len(angle) > 1 else p['label']}",
        f"5/ {angle[2] if len(angle) > 2 else cta}",
        f"6/ {cta} {tags_str(d.tags)}",
        f"7/ {NFA} Verify every claim against the official docs.",
    ]
    d.body = (NL + NL).join(t)
    d.media_brief = media
    return d


def tags_str(tags):
    return " ".join(tags)


def render_x_quote(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    short = min(angle, key=len)
    body = f"{hook}{NL}{NL}{short}{NL}{NL}Which part would you check first? {tags_str(d.tags)}"
    d.body = fit(body, 242)
    return d


def render_telegram_announcement(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    title = p["label"].upper()
    bullets = NL.join(f"• {line}" for line in angle)
    d.body = (
        f"{emoji(p['emoji'], rng)} **{title}**{NL}{NL}"
        f"{hook}{NL}{NL}{bullets}{NL}{NL}"
        f"{cta}{NL}{NL}{tags_str(d.tags)}"
    )
    d.media_brief = media
    d.extra["pin"] = True
    return d


def render_telegram_quiz(d, rng):
    q = rng.choice(QUIZZES)
    d.proof_ids = [q["fact"]] + [i for i in d.proof_ids if i != q["fact"]]
    letters = "ABCD"
    opts = NL.join(f"{letters[i]}) {o}" for i, o in enumerate(q["options"]))
    d.body = (
        f"{emoji('learn', rng)} **FLOKI QUIZ — 60 seconds**{NL}{NL}"
        f"{q['q']}{NL}{NL}{opts}{NL}{NL}"
        f"Drop your answer below. Answer + explanation in 30 minutes."
    )
    d.extra["answer_key"] = f"{letters[q['answer']]}) {q['options'][q['answer']]}"
    d.extra["explanation"] = q["why"]
    d.risk_note = "education"
    return d


def render_telegram_poll(d, rng):
    poll = rng.choice(POLLS)
    icons = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"]
    opts = NL.join(f"{icons[i]} {o}" for i, o in enumerate(poll["options"]))
    d.body = (
        f"{emoji('community', rng)} **POLL**{NL}{NL}"
        f"{poll['q']}{NL}{NL}{opts}{NL}{NL}"
        f"{poll['context']}Drop your answer — no wrong answers in a poll."
    )
    d.extra["poll_options"] = poll["options"]
    return d


def render_instagram_carousel(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    slides = [f"SLIDE 1 (hook): {hook}"]
    for i, line in enumerate(angle, start=2):
        slides.append(f"SLIDE {i}: {line}")
    slides.append(f"SLIDE {len(angle) + 2} (CTA): {cta}")
    slides.append(f"SLIDE {len(angle) + 3} (disclaimer): {NFA} High-risk, speculative asset.")
    caption = (
        f"{hook}{NL}{NL}"
        + NL.join(f"→ {line}" for line in angle)
        + f"{NL}{NL}{cta}{NL}{NL}{tags_str(d.tags)}"
    )
    d.body = NL.join(slides) + f"{NL}{NL}CAPTION:{NL}{caption}"
    d.media_brief = media
    d.extra["slides"] = len(angle) + 3
    return d


def render_instagram_caption(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    d.body = (
        f"{hook}{NL}{NL}"
        + NL.join(f"→ {line}" for line in angle)
        + f"{NL}{NL}{cta}{NL}{NL}{tags_str(d.tags)}"
    )
    d.media_brief = media
    return d


def render_tiktok_short(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    d.body = (
        f"HOOK (0-3s) — text on screen: \"{hook}\"{NL}"
        f"VO: \"{min(angle, key=len)}\"{NL}"
        f"B-ROLL: {media}{NL}{NL}"
        f"BEAT 2 (3-9s) — text: \"{angle[0][:70]}…\"{NL}"
        f"VO: {angle[0]}{NL}"
        f"CUT: real product screen / on-chain proof, no price charts{NL}{NL}"
        f"BEAT 3 (9-18s) — VO: {angle[1] if len(angle) > 1 else p['label']}{NL}{NL}"
        f"BEAT 4 (18-28s) — VO: {angle[2] if len(angle) > 2 else cta}{NL}"
        f"ON-SCREEN: \"{p['label']}\"{NL}{NL}"
        f"CTA (28-35s) — VO: \"{cta}\"{NL}"
        f"ON-SCREEN: follow for the receipts, not the hype{NL}{NL}"
        f"CAPTION: {hook} {tags_str(d.tags)} {NFA}{NL}"
        f"DO NOT SAY: guaranteed, 100x, price target, buy now, last chance."
    )
    d.media_brief = media
    d.extra["duration_s"] = 35
    return d


def render_youtube_short(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    d.body = (
        f"TITLE: {fit(hook, 70)}{NL}{NL}"
        f"[0:00] HOOK — on camera: \"{hook}\"{NL}"
        f"[0:04] Proof 1 — {angle[0]}{NL}"
        f"[0:15] Proof 2 — {angle[1] if len(angle) > 1 else p['label']}{NL}"
        f"[0:28] Proof 3 — {angle[2] if len(angle) > 2 else cta}{NL}"
        f"[0:42] Honest caveat — high-risk speculative asset; roadmap items without a date are not deliveries.{NL}"
        f"[0:50] CTA — {cta}{NL}{NL}"
        f"THUMBNAIL: {media}{NL}"
        f"DESCRIPTION TAIL: {tags_str(d.tags)} | {NFA}"
    )
    d.media_brief = media
    return d


def _ts(seconds: int) -> str:
    return f"{seconds // 60}:{seconds % 60:02d}"


def render_youtube_description(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    chapters = NL.join(f"{_ts((i - 1) * 42)} {chr(64 + i)}. {line[:52]}…" for i, line in enumerate(angle, start=1))
    d.body = (
        f"{hook}{NL}{NL}"
        f"In this video we walk through what FLOKI actually ships — and what is still just a roadmap line.{NL}{NL}"
        + NL.join(f"• {line}" for line in angle)
        + f"{NL}{NL}CHAPTERS{NL}{chapters}{NL}{NL}"
        f"LINKS{NL}Official site: floki.com (verify the contract address there — copycat 'Floki' tokens exist){NL}"
        f"Facts & sources for every claim in this video are listed in the pinned comment.{NL}{NL}"
        f"{cta}{NL}{NL}{tags_str(d.tags)}"
    )
    d.media_brief = media
    return d


def render_reddit_post(d, rng):
    p, hook, angle, cta, media = _pick_pillar_context(d.pillar, rng)
    d.body = (
        f"{hook}{NL}{NL}"
        f"I went through the Floki ecosystem and tried to separate what's live from what's announced. "
        f"Writing it up because most posts about memecoins are either pure hype or pure doom, and both are useless.{NL}{NL}"
        + NL.join(f"- {line}" for line in angle)
        + f"{NL}{NL}What I'd want a skeptic to check: does the product exist, can you use it today, "
        f"and is the pending stuff clearly labelled as pending.{NL}{NL}"
        f"Counter-arguments welcome — especially from people who tried Valhalla or used the locker.{NL}{NL}"
        f"Disclosure: I hold FLOKI. {cta} {NFA}"
    )
    d.media_brief = media
    d.tags = []
    return d


RENDERERS = {
    ("x", "post"): render_x_post,
    ("x", "thread"): render_x_thread,
    ("x", "quote_hook"): render_x_quote,
    ("telegram", "announcement"): render_telegram_announcement,
    ("telegram", "quiz"): render_telegram_quiz,
    ("telegram", "poll_brief"): render_telegram_poll,
    ("instagram", "carousel"): render_instagram_carousel,
    ("instagram", "caption"): render_instagram_caption,
    ("tiktok", "short_script"): render_tiktok_short,
    ("youtube", "short_script"): render_youtube_short,
    ("youtube", "video_description"): render_youtube_description,
    ("reddit", "discussion_post"): render_reddit_post,
}


# ------------------------------------------------------------------- agents
# Writers are optimised for reach, which is exactly why they need a guard.
# With some probability a draft gets a "growth instinct" line, so VIGIL has
# real work to do instead of rubber-stamping. `safe=True` on retry disables it.
SPICE_SOFT = [
    "Honestly this is the most undervalued memecoin out there.",
    "Cheap right now, if you ask me.",
    "Arguably the best memecoin of 2026.",
    "Mobile version coming very soon, mark my words.",
]
SPICE_HARD = [
    "Guaranteed to be the next big thing.",
    "Easy 100x from here.",
    "Buy now before it's too late.",
    "To the moon.",
]
SPICE_RATE = {"soft": 0.22, "hard": 0.10}


def _spice(d: Draft, rng: random.Random) -> str | None:
    roll = rng.random()
    if roll < SPICE_RATE["hard"]:
        line, kind = rng.choice(SPICE_HARD), "hard"
    elif roll < SPICE_RATE["hard"] + SPICE_RATE["soft"]:
        line, kind = rng.choice(SPICE_SOFT), "soft"
    else:
        return None
    if d.channel == "x":
        d.body = fit(line + " " + d.body, 242)
    else:
        d.body = d.body.rstrip() + "\n\n" + line
    return kind


class Agent:
    codename = "AGENT"
    role = ""
    glyph = "◆"
    handles: tuple[str, ...] = ()

    def __init__(self):
        self.status = "idle"
        self.current_task = ""
        self.tasks_done = 0
        self.last_action = ""

    def snapshot(self) -> dict:
        return {
            "codename": self.codename,
            "role": self.role,
            "glyph": self.glyph,
            "channel": ", ".join(self.handles) if self.handles else "all",
            "status": self.status,
            "current_task": self.current_task,
            "tasks_done": self.tasks_done,
            "last_action": self.last_action,
        }

    def draft(self, channel: str, fmt: str, pillar: str, rng: random.Random,
              safe: bool = False) -> Draft:
        d = Draft(
            agent=self.codename,
            channel=channel,
            fmt=fmt,
            pillar=pillar,
            hook="",
            proof_ids=_proof_ids(pillar, rng),
            tags=_tags(pillar, rng, 3 if channel in ("instagram", "tiktok", "youtube") else 2),
        )
        d.risk_note = PILLARS[pillar]["label"]
        renderer = RENDERERS[(channel, fmt)]
        d = renderer(d, rng)
        d.extra["spice"] = None if safe else _spice(d, rng)
        d.sources = KB.sources(d.proof_ids)
        d.hook = d.hook or d.body.split("\n")[0][:90]
        return d


class SkaldX(Agent):
    codename = "SKALD"
    role = "X / Twitter writer — hooks, threads, one-liners"
    glyph = "⚔️"
    handles = ("x",)

    def draft(self, channel, fmt, pillar, rng, safe: bool = False):
        d = super().draft(channel, fmt, pillar, rng, safe=safe)
        # X is unforgiving: keep only the highest-signal tags
        d.tags = d.tags[:2]
        return d


class HeraldTelegram(Agent):
    codename = "HERALD"
    role = "Community broadcaster — announcements, quizzes, polls"
    glyph = "📣"
    handles = ("telegram",)


class VerseVideo(Agent):
    codename = "VERSE"
    role = "Short-form video scripter — TikTok, Reels, Shorts"
    glyph = "🎬"
    handles = ("tiktok", "youtube")


class SagaLongform(Agent):
    codename = "SAGA"
    role = "Long-form & discussion — Reddit, YouTube descriptions"
    glyph = "📜"
    handles = ("reddit", "youtube")


class RuneVisual(Agent):
    codename = "RUNE"
    role = "Visual director — carousels, captions, art briefs"
    glyph = "🎨"
    handles = ("instagram",)


class VigilGuard(Agent):
    codename = "VIGIL"
    role = "Compliance & fact-guard — absolute veto power"
    glyph = "🛡️"
    handles = ()

    def __init__(self):
        super().__init__()
        self.blocked = 0
        self.approved = 0
        self.edited = 0


class AtlasPlanner(Agent):
    codename = "ATLAS"
    role = "Strategist — weekly themes, slot assignment, cadence"
    glyph = "🗺️"
    handles = ()

    def __init__(self):
        super().__init__()
        self.cycles = 0


class MetraAnalyst(Agent):
    codename = "METRA"
    role = "Analyst — projected reach, A/B learnings, weekly report"
    glyph = "📊"
    handles = ()

    def __init__(self):
        super().__init__()
        self.reports = 0


WRITERS = {
    "SKALD": SkaldX(),
    "HERALD": HeraldTelegram(),
    "VERSE": VerseVideo(),
    "SAGA": SagaLongform(),
    "RUNE": RuneVisual(),
}
