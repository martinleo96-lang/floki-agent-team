#!/usr/bin/env bash
# verify_repo.sh — memeriksa repo lokal sebelum/sesudah push.
# Output-nya dirancang untuk bisa Anda salin-tempel ke chat kalau ada masalah.
#
# Pakai:  ./scripts/verify_repo.sh

cd "$(dirname "$0")/.." || exit 1
FAIL=0
say() { printf '%-34s %s\n' "$1" "$2"; }

echo "=================================================="
echo " VERIFIKASI REPO — floki-agent-team"
echo "=================================================="

# 1. git repo?
if git rev-parse --git-dir >/dev/null 2>&1; then
  say "git repository" "OK (branch: $(git rev-parse --abbrev-ref HEAD 2>/dev/null))"
else
  say "git repository" "BELUM ADA — jalankan: git init -b main"
  FAIL=1
fi

# 2. commit?
COMMITS=$(git rev-list --count HEAD 2>/dev/null || echo 0)
if [ "$COMMITS" -gt 0 ] 2>/dev/null; then
  say "commit" "OK ($COMMITS commit)"
else
  say "commit" "BELUM ADA — jalankan: git add . && git commit -m 'init'"
  FAIL=1
fi

# 3. remote
REMOTE=$(git remote get-url origin 2>/dev/null || echo "")
if [ -n "$REMOTE" ]; then
  say "remote origin" "$REMOTE"
  case "$REMOTE" in
    *flocki*) say "  ⚠ ejaan remote" "tertulis 'flocki' — seharusnya 'floki'" ;;
    *floki-agent-team*) say "  ejaan remote" "OK" ;;
    *) say "  ejaan remote" "periksa manual: $REMOTE" ;;
  esac
else
  say "remote origin" "BELUM DISET — git remote add origin https://github.com/martinleo96-lang/floki-agent-team.git"
  FAIL=1
fi

# 4. jumlah file terlacak
TRACKED=$(git ls-files 2>/dev/null | wc -l | tr -d ' ')
say "file terlacak" "$TRACKED (perkiraan benar: 19-23)"
[ "${TRACKED:-0}" -lt 10 ] 2>/dev/null && { say "  ⚠ terlalu sedikit" "mungkin 'git add .' belum dijalankan"; FAIL=1; }

# 5. file wajib
for f in README.md config.json data/floki_facts.json data/compliance.json \
         engine/orchestrator.py engine/server.py web/index.html; do
  if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then :; else
    say "file wajib hilang" "$f"; FAIL=1
  fi
done
[ "$FAIL" -eq 0 ] && say "file wajib" "lengkap"

# 6. file sensitif — INI YANG PALING PENTING
SENSITIVE=$(git ls-files 2>/dev/null | grep -Ei '(^|/)\.env|(^|/)state/|\.key$|\.pem$|credential|secret|\.zip$' || true)
if [ -n "$SENSITIVE" ]; then
  say "FILE SENSITIF IKUT" "GAGAL — harus dikeluarkan dari repo:"
  echo "$SENSITIVE" | sed 's/^/      /'
  echo "      → git rm --cached <file> && git commit -m 'remove secret'"
  FAIL=1
else
  say "file sensitif" "bersih (tidak ada .env / state / *.key)"
fi

# 7. perubahan belum di-commit
DIRTY=$(git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
if [ "${DIRTY:-0}" -eq 0 ]; then say "working tree" "bersih"; else say "working tree" "$DIRTY file belum di-commit"; fi

# 8. sinkron dengan remote?
if [ -n "$REMOTE" ] && [ "$COMMITS" -gt 0 ] 2>/dev/null; then
  UPSTREAM=$(git rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>/dev/null || echo "")
  if [ -n "$UPSTREAM" ]; then
    AHEAD=$(git rev-list --count '@{u}..HEAD' 2>/dev/null || echo "?")
    say "upstream" "$UPSTREAM ($AHEAD commit belum ter-push)"
  else
    say "upstream" "belum diset — push pertama: git push -u origin main"
  fi
fi

echo "--------------------------------------------------"
if [ "$FAIL" -eq 0 ]; then
  echo " HASIL: SIAP / SEHAT ✓"
  echo " Kalau push sudah dilakukan, repo Anda berisi file yang benar."
else
  echo " HASIL: ADA YANG HARUS DIBERESKAN ✗ (lihat baris di atas)"
fi
echo "=================================================="
echo "Salin seluruh output ini kalau butuh bantuan."
