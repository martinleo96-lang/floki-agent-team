#!/usr/bin/env python3
"""Optional real publisher: pushes approved Telegram items to a chat.

Off by default. Set these environment variables to go live:
    TELEGRAM_BOT_TOKEN=123456:ABC...        (from @BotFather)
    TELEGRAM_CHAT_ID=@yourchannel_or_-100xxx

Usage:
    python3 scripts/publish_telegram.py            # dry run (prints what it would send)
    python3 scripts/publish_telegram.py --live     # actually sends
    python3 scripts/publish_telegram.py --live --limit 3

Only items that are (a) telegram, (b) not rejected, (c) not already posted,
and (d) approved by you OR approved by VIGIL are sent. Disclaimers are already
baked into the copy by VIGIL.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.orchestrator import ENGINE  # noqa: E402

API = "https://api.telegram.org/bot{token}/sendMessage"


def candidates(limit: int):
    out = []
    for i in ENGINE.items:
        if i["channel"] != "telegram" or i["status"] == "rejected" or i.get("posted"):
            continue
        if i["human"] == "rejected":
            continue
        out.append(i)
        if len(out) >= limit:
            break
    return out


def send(token: str, chat: str, text: str) -> dict:
    data = urllib.parse.urlencode({
        "chat_id": chat,
        "text": text,
        "parse_mode": "Markdown",
        "disable_web_page_preview": "true",
    }).encode()
    req = urllib.request.Request(API.format(token=token), data=data)
    with urllib.request.urlopen(req, timeout=20) as resp:
        return json.loads(resp.read())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true", help="actually send; default is dry run")
    ap.add_argument("--limit", type=int, default=5)
    args = ap.parse_args()

    token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat = os.environ.get("TELEGRAM_CHAT_ID", "")
    items = candidates(args.limit)
    if not items:
        print("nothing to publish (no approved telegram items pending).")
        return

    for i in items:
        print("=" * 70)
        print(f"#{i['id']}  {i['scheduled_for']}  verdict={i['compliance']['verdict']}")
        print(i["body"][:600])
        if not args.live:
            continue
        if not (token and chat):
            print("!! TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not set — aborting live send")
            return
        try:
            res = send(token, chat, i["body"])
            ok = res.get("ok")
            print("sent:", ok)
            if ok:
                i["posted"] = {"at": "now", "url": ""}
        except Exception as exc:  # network or API error
            print("send failed:", exc)
            return

    if args.live:
        ENGINE.save()
        print("\nstate saved.")
    else:
        print("\nDRY RUN — nothing was sent. Re-run with --live when ready.")


if __name__ == "__main__":
    main()
