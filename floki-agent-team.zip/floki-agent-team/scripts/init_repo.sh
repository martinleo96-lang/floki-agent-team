#!/usr/bin/env bash
# init_repo.sh — menyiapkan folder ini sebagai repo git yang siap di-push.
#
# Pakai:  ./scripts/init_repo.sh https://github.com/USERNAME/floki-agent-team.git
# (tanpa argumen: hanya init + commit, remote disetel belakangan)
#
# Aman dijalankan: TIDAK menghapus apa pun, TIDAK push, dan berhenti kalau
# menemukan file yang berpotensi rahasia sebelum commit.

set -euo pipefail
cd "$(dirname "$0")/.."

REMOTE="${1:-}"

# ---------- 0. prasyarat
command -v git >/dev/null 2>&1 || { echo "✗ git belum terpasang. Lihat bagian 0 di PANDUAN_BUAT_REPO.md"; exit 1; }
[ -f .gitignore ] || { echo "✗ .gitignore tidak ditemukan — Anda mungkin di folder yang salah."; exit 1; }
[ -f README.md ]  || { echo "✗ README.md tidak ditemukan — Anda mungkin di folder yang salah."; exit 1; }

if [ -z "$(git config --global user.name || true)" ] || [ -z "$(git config --global user.email || true)" ]; then
  echo "✗ Identitas git belum diset. Jalankan dulu:"
  echo '    git config --global user.name "Nama Anda"'
  echo '    git config --global user.email "email@example.com"'
  exit 1
fi

# ---------- 1. init
if [ -d .git ]; then
  echo "• .git sudah ada — melewati git init"
else
  git init -b main >/dev/null
  echo "✓ git init (branch: main)"
fi

# ---------- 2. staging
git add .
echo "✓ git add ."

# ---------- 3. pemeriksaan keamanan
RISKY=$(git diff --cached --name-only | grep -Ei '\.env|(^|/)state/|\.key$|\.pem$|credential|secret' || true)
if [ -n "$RISKY" ]; then
  echo "✗ BERHENTI. File berikut seharusnya tidak masuk repo:"
  echo "$RISKY" | sed 's/^/    /'
  echo "  Periksa .gitignore, lalu: git reset"
  exit 1
fi
echo "✓ tidak ada file rahasia di staging"

BIG=$(git diff --cached --name-only | xargs -I{} sh -c 'test -f "{}" && [ $(wc -c < "{}") -gt 104857600 ] && echo "{}"' 2>/dev/null || true)
if [ -n "$BIG" ]; then
  echo "✗ BERHENTI. File > 100 MB (GitHub akan menolak):"
  echo "$BIG" | sed 's/^/    /'
  exit 1
fi

COUNT=$(git diff --cached --name-only | wc -l | tr -d ' ')
echo "• $COUNT file akan di-commit:"
git diff --cached --name-only | sed 's/^/    /'

# ---------- 4. commit
if git rev-parse --verify HEAD >/dev/null 2>&1; then
  git commit -m "chore: update FLOKI agent team" >/dev/null
  echo "✓ commit dibuat (update)"
else
  git commit -m "feat: FLOKI agent team — autonomous promo engine (8 agents, VIGIL compliance guard)" >/dev/null
  echo "✓ commit pertama dibuat"
fi

# ---------- 5. remote
if [ -n "$REMOTE" ]; then
  if git remote | grep -qx origin; then
    git remote set-url origin "$REMOTE"
    echo "✓ remote origin diperbarui → $REMOTE"
  else
    git remote add origin "$REMOTE"
    echo "✓ remote origin ditambahkan → $REMOTE"
  fi
fi

# ---------- 6. instruksi berikutnya
echo
if [ -n "$REMOTE" ]; then
  echo "Langkah terakhir:"
  echo "    git push -u origin main"
  echo "  Saat diminta password, tempel Personal Access Token (bukan password akun)."
else
  echo "Langkah berikutnya:"
  echo "  1. Buat repo KOSONG & PRIVATE di https://github.com/new"
  echo "     (jangan centang README / .gitignore / license)"
  echo "  2. git remote add origin https://github.com/USERNAME/floki-agent-team.git"
  echo "  3. git push -u origin main"
fi
echo
echo "Pemeriksaan akhir:  git ls-files | grep -E '\\.env|state/|outputs/'   → harus kosong"
