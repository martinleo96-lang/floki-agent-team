# FLOKI Agent Team — autonomous promo engine

A working team of 8 agents that keeps producing FLOKI promotional content across
**X, Telegram, Instagram, TikTok, YouTube and Reddit** — planning, writing,
fact-checking and reporting on its own, with a compliance agent that can veto
anything risky.

No API keys. No paid services. No `pip install`. Pure Python 3 standard library.

```
python3 -m engine.server        → dashboard on http://localhost:8080
```

---

## The team

| Agent | Role | What it actually does |
|---|---|---|
| **ATLAS** 🗺️ | Strategist | Builds the 30-day plan, assigns every slot to a writer, keeps cadence and pillar balance |
| **SKALD** ⚔️ | X writer | Posts, threads, quote-hooks — hard 280-char discipline |
| **HERALD** 📣 | Community broadcaster | Telegram announcements, quizzes with answer keys, polls |
| **VERSE** 🎬 | Short-form video | TikTok/Reels beat-by-beat scripts (hook → beats → CTA → caption) |
| **RUNE** 🎨 | Visual director | Instagram carousels (slide-by-slide) + art briefs for every visual post |
| **SAGA** 📜 | Long-form | Reddit discussion posts, YouTube descriptions (no hashtag spam) |
| **VIGIL** 🛡️ | Compliance & fact-guard | Scans every draft, blocks forbidden claims, rewrites risky phrasing, force-adds disclaimers. **Veto power.** |
| **METRA** 📊 | Analyst | Projected reach, approval rates, A/B learnings, weekly report |

The loop: **ATLAS plans → writer drafts → VIGIL reviews → queue → you approve → publish.**

## Why this doesn't look like a shill bot

- **Every claim is sourced.** All 24 facts live in `data/floki_facts.json` with a
  source URL and a confidence level. VIGIL rejects any draft whose claims aren't
  traceable there. Two low-confidence facts are marked `publish_safe: false` and
  can never be used.
- **10 hard blocks** (price predictions, "guaranteed", "100x", fake urgency,
  airdrop-claim patterns, seed-phrase requests, unverified partnership/listing claims…).
- **5 soft flags** get auto-rephrased (superlatives, "cheap", "soon", price figures)
  and the item is marked *repaired* with its risk score reduced.
- **Writers are optimised for reach, so they sometimes slip.** A fraction of drafts
  gets a hype line on purpose; VIGIL catches it, the draft goes back with
  "safe-mode on", and the veto is logged. That's the design — not a rubber stamp.
- **The Nov 2026 Telegram-bot exploit is in the knowledge base** and the
  TRANSPARENCY pillar posts about it *with* the security guidance. Hiding a bad
  week is the fastest way to lose a community.
- Nothing is auto-posted anywhere. You approve first, then hand it to your
  scheduler (or turn on the optional Telegram publisher).

## Files

```
floki-agent-team/
├── config.json                 campaign goal, voice, pillars per weekday, cadence, port
├── data/floki_facts.json       24 sourced facts + contract addresses + cautions
├── data/compliance.json        hard blocks, soft flags, disclosures, per-channel limits
├── engine/
│   ├── core.py                 knowledge base, text utils, Draft model
│   ├── content_bank.py         hooks/angles/CTAs/media briefs per pillar + quiz & poll banks
│   ├── agents.py               the 8 agents + all channel renderers
│   ├── guard.py                VIGIL's rules engine
│   ├── planner.py              ATLAS's 30-day slot plan
│   ├── orchestrator.py         the autonomous loop, persistence, metrics, CSV
│   └── server.py               HTTP API + dashboard host (stdlib)
├── web/index.html              mission-control dashboard (single file, no CDN)
├── scripts/publish_telegram.py optional real publisher (dry-run by default)
├── outputs/
│   ├── queue.jsonl             every generated item, full JSON
│   ├── content_calendar.md     calendar view by day
│   └── report.md               METRA's weekly report
└── state/engine_state.json     persists queue + cursor (restart-safe)
```

## Dashboard

- **Agent roster** with live status and what each agent is doing right now
- **Content queue** with channel filters, full copy, sources, visual brief, answer keys
- **Approve / reject / hold** per item, **copy** to clipboard
- **VIGIL panel**: clean approvals · auto-repaired · drafts blocked · pass rate
- **METRA report** and **calendar** tabs (live from disk)
- **Run cycle** to force more output, **Pause/Resume** the autonomous loop, **Export CSV**

Ticks every 18s by default (`config.json → engine.tick_seconds`). Restarting
resumes from disk instead of duplicating the queue.

## Going from "drafted" to "actually posted"

1. **Manual (default):** approve items, hit `copy`, paste into the platform. Zero risk.
2. **Scheduler (no code):** point Zapier / Make / n8n at
   `GET /api/feed.json` → it returns approved, unposted items with channel + copy.
   After posting, have the automation call `POST /api/mark-posted {"id":"0042","url":"…"}`.
3. **Telegram direct:**
   ```bash
   export TELEGRAM_BOT_TOKEN="123:ABC…"
   export TELEGRAM_CHAT_ID="@yourchannel"
   python3 scripts/publish_telegram.py            # dry run, shows what would send
   python3 scripts/publish_telegram.py --live     # sends
   ```

For X/Instagram/TikTok, use option 2 — official APIs there need paid tiers and
OAuth, and a scheduler you already trust is the safer path.

## API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/state?limit=60` | full dashboard payload (agents, queue, metrics, log, vetoes) |
| GET | `/api/feed.json` | approved + unposted items for external automations |
| GET | `/api/export.csv` | CSV of the whole queue |
| GET | `/api/file?name=calendar\|report\|queue` | generated markdown/JSONL |
| POST | `/api/cycle` `{"n":3}` | generate n more items now |
| POST | `/api/pause` · `/api/resume` | stop/start the autonomous loop |
| POST | `/api/verdict` `{"id":"0042","action":"approved"}` | your review decision |
| POST | `/api/mark-posted` `{"id":"0042","url":"…"}` | close the loop after publishing |
| POST | `/api/export` | rewrite all output files |

## Tuning it to your own strategy

| Want to change | Edit |
|---|---|
| Voice, audience, positioning, CTA | `config.json → campaign` |
| Which theme runs on which weekday | `config.json → pillars` |
| How often each channel posts | `engine/planner.py → WEEKLY`, `SLOT_TIMES` |
| New hooks / angles / CTAs / briefs | `engine/content_bank.py` |
| New facts, or retire a claim | `data/floki_facts.json` |
| Stricter/looser guardrails | `data/compliance.json` |
| Add a channel | add renderer in `agents.py` → register in `RENDERERS` → add to `config.json` channels |

## Honest limits

- **Projected reach is a heuristic**, seeded from channel + format + compliance
  score. It is not analytics and gets no data from any platform. Wire real
  numbers in later if you connect APIs.
- **Templates, not a language model.** Deterministic, free, fast — but the copy
  varies within a curated set of angles. Swap the renderers for an LLM call if you
  want infinite variation (keep VIGIL in front of it; that's the important part).
- **Promotion ≠ price support.** Nothing here promises returns, and the copy says
  so on every post. FLOKI is a high-risk speculative asset; that line is not
  optional in this system by design.
- **Verify the contract address** from floki.com before promoting any link —
  dozens of copycat "Floki" tokens exist. Addresses are in `data/floki_facts.json`.

_Facts compiled 2026-11-16 from public sources listed in the facts file. Re-check
before any campaign that runs longer than a few weeks._
