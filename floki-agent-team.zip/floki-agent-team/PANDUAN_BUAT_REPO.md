# Panduan lengkap: membuat repo GitHub untuk proyek ini

Ditulis untuk diikuti dari nol. Pilih **satu** jalur:

- **Jalur A — GitHub Desktop** (tanpa terminal, klik-klik). Cocok kalau Anda tidak nyaman dengan command line.
- **Jalur B — Terminal / command line** (paling cepat, 3 perintah inti).
- **Jalur C — GitHub CLI** (`gh`) — kalau Anda ingin semuanya dari terminal termasuk membuat repo-nya.

Semua jalur berakhir di tempat yang sama: kode proyek ada di GitHub, repo privat.

---

## 0. Prasyarat (5 menit)

**Akun GitHub.** Daftar di https://github.com/signup. Verifikasi email — tanpa verifikasi, GitHub menolak push pertama Anda.

**Git terpasang** (untuk Jalur B dan C). Cek:

```bash
git --version
```

Kalau muncul `command not found` / `'git' is not recognized`:

| OS | Cara pasang |
|---|---|
| Windows | Download https://git-scm.com/download/win → install → **buka PowerShell baru** (jangan pakai yang lama, PATH belum ter-refresh) |
| macOS | Terminal: `xcode-select --install` (atau `brew install git`) |
| Linux (Debian/Ubuntu) | `sudo apt update && sudo apt install git` |

**Identitas git** — wajib sekali saja, kalau tidak commit akan gagal:

```bash
git config --global user.name "Nama Anda"
git config --global user.email "email-yang-dipakai-di-github@example.com"
```

> Email harus sama dengan yang terdaftar di GitHub, kalau tidak commit tidak akan terhubung ke profil Anda (tetap jalan, tapi tidak muncul sebagai kontribusi Anda).

**File proyek.** Download `floki-agent-team.zip` dari workspace, lalu ekstrak. Anda akan punya folder `floki-agent-team/` berisi `README.md`, `engine/`, `data/`, `web/`, dst.

---

## Jalur A — Lewat GitHub Desktop (tanpa terminal)

1. Download **GitHub Desktop**: https://desktop.github.com → install → buka → **Sign in to GitHub.com** → login lewat browser.
2. Menu **File → Add local repository…**
3. Klik **Choose…**, arahkan ke folder `floki-agent-team` hasil ekstrak, klik **Add repository**.
   - Kalau muncul "This directory does not appear to be a Git repository. Would you like to create a repository here instead?" → klik **create a repository**.
4. Di panel kiri, isi **Description**: `Autonomous FLOKI promo agent team`. Biarkan **Git ignore**: None (kita sudah punya `.gitignore` sendiri), **License**: None dulu.
5. Klik **Initialize repository** / **Create repository**.
6. Panel kiri akan menampilkan daftar file. Isi kolom **Summary** di kiri bawah:
   `feat: FLOKI agent team — autonomous promo engine (8 agents, VIGIL compliance guard)`
7. Klik **Commit to main**.
8. Klik tombol **Publish repository** di kanan atas.
9. Di dialog yang muncul:
   - **Name**: `floki-agent-team`
   - **Description**: bebas
   - **Keep this code private** → **centang**. Ini penting, lihat bagian 5.
10. Klik **Publish repository**. Selesai — repo sudah ada di `github.com/USERNAME/floki-agent-team`.

---

## Jalur B — Terminal (paling cepat)

### B1. Buat repo kosong di GitHub

1. Buka https://github.com/new
2. **Repository name**: `floki-agent-team`
3. **Description**: `Autonomous FLOKI promo agent team — 8 agents, compliance guard, 6 channels`
4. Pilih **Private** ← jangan dilewatkan
5. **JANGAN** centang "Add a README file", "Add .gitignore", atau "Choose a license". Ketiganya bikin repo tidak kosong, dan push pertama Anda akan ditolak karena ada dua versi riwayat.
6. Klik **Create repository**.

GitHub lalu menampilkan halaman "Quick setup". Abaikan semua yang di situ, kita pakai perintah sendiri.

### B2. Push proyek dari komputer Anda

Masuk ke folder proyek, lalu jalankan:

```bash
cd path/ke/floki-agent-team

git init -b main
git add .
git status                    # ← periksa dulu: tidak boleh ada .env, *.key, state/, outputs/
git commit -m "feat: FLOKI agent team — autonomous promo engine (8 agents, VIGIL compliance guard)"

git remote add origin https://github.com/USERNAME/floki-agent-team.git
git push -u origin main
```

Ganti `USERNAME` dengan username GitHub Anda.

**Penjelasan tiap baris** (biar Anda tahu apa yang terjadi, bukan hafal):

- `git init -b main` — membuat repositori git lokal dengan branch utama bernama `main` (default lama: `master`, GitHub sekarang pakai `main`).
- `git add .` — memasukkan semua file ke *staging area*, **kecuali** yang tercantum di `.gitignore`.
- `git status` — daftar file yang akan di-commit. **Ini checkpoint keamanan Anda.** Kalau `.env` atau file token muncul di sini, hentikan dan periksa `.gitignore`.
- `git commit -m "..."` — menyimpan snapshot permanen di komputer Anda, dengan pesan.
- `git remote add origin ...` — memberi tahu git "repo tujuan ada di alamat ini".
- `git push -u origin main` — mengunggah commit ke GitHub dan menyetel `origin/main` sebagai upstream, supaya nanti cukup `git push`.

### B3. Autentikasi — bagian yang paling sering bikin orang berhenti

`git push` akan minta username dan password. **Password akun GitHub Anda tidak akan berfungsi.** GitHub mewajibkan *Personal Access Token* (PAT) atau SSH.

**Opsi 1 — Personal Access Token (paling cepat, 2 menit):**

1. Buka https://github.com/settings/tokens?type=beta (fine-grained token)
2. **Token name**: `laptop-floki-agent`
3. **Expiration**: 90 days (jangan "No expiration")
4. **Repository access**: `Only select repositories` → pilih `floki-agent-team`
5. **Permissions → Repository permissions → Contents**: ubah jadi **Read and write**. (Metadata otomatis Read.)
6. **Generate token** → salin token (`github_pat_...`). **Hanya ditampilkan sekali.**
7. Saat `git push` minta password: tempel token itu (bukan password akun).
   Di terminal, saat menempel, karakter tidak akan terlihat — itu normal, tekan Enter.

Supaya tidak ditanya berulang kali:

```bash
git config --global credential.helper store   # menyimpan plaintext di ~/.git-credentials
```

Lebih aman: pakai `credential.helper` bawaan OS — macOS `osxkeychain`, Windows `manager`, Linux `libsecret`.

**Opsi 2 — SSH key (sekali setup, tidak pernah ditanya lagi):**

```bash
ssh-keygen -t ed25519 -C "email-anda@example.com"     # Enter 3x untuk default
cat ~/.ssh/id_ed25519.pub                             # salin seluruh output
```

Tempel ke https://github.com/settings/keys → **New SSH key** → Title bebas, Key type *Authentication Key*, tempel → **Add SSH key**.

Tes: `ssh -T git@github.com` → harus muncul `Hi USERNAME! You've successfully authenticated`.

Lalu ubah remote ke SSH:

```bash
git remote set-url origin git@github.com:USERNAME/floki-agent-team.git
```

---

## Jalur C — GitHub CLI (`gh`)

Kalau Anda ingin membuat repo tanpa membuka browser sama sekali:

```bash
# pasang gh: https://cli.github.com  (Windows: winget install GitHub.cli | macOS: brew install gh)
gh auth login            # pilih GitHub.com → HTTPS → login lewat browser

cd path/ke/floki-agent-team
git init -b main
git add .
git commit -m "feat: FLOKI agent team"

gh repo create floki-agent-team --private --source=. --remote=origin --push
```

Satu perintah terakhir itu membuat repo privat, menyetel remote, dan push sekaligus.

---

## 5. Setelah repo jadi — 4 hal yang harus dibereskan

**1. Pastikan benar-benar privat.** Buka repo → **Settings** → scroll ke **Danger Zone** → kalau tertulis "Change visibility → Make public", artinya sudah privat (tombolnya menawarkan perubahan ke publik). Kalau sebaliknya, repo Anda publik — klik dan ubah sekarang.

Alasannya konkret: folder ini berisi seluruh playbook kampanye, aturan compliance, knowledge base yang Anda kurasi, dan daftar klaim yang sengaja dilarang. Kalau publik, siapa pun bisa membaca strategi Anda dan menyiapkan serangan narasi yang tepat sasaran.

**2. Cek tidak ada secret yang ikut.** Di halaman repo, buka tiap file yang namanya mengandung `env`, `key`, `token`, atau `secret`. Kalau ada — hapus file itu, commit, lalu **revoke** tokennya di tempat asalnya. Menghapus file di commit berikutnya **tidak** menghilangkan jejaknya dari histori git.

**3. Tulis deskripsi & topik.** Di halaman utama repo, klik ikon gear di sebelah kanan "About": isi Description, dan Topics: `crypto`, `agents`, `content-automation`, `floki`.

**4. Proteksi branch (opsional tapi disarankan).** **Settings → Branches → Add branch protection rule** → pattern `main` → centang *Require a pull request before merging*. Berguna kalau nanti Anda menambahkan kolaborator: tidak ada yang bisa mengubah copy atau aturan compliance langsung di `main`.

---

## 6. Error yang paling sering muncul (dan solusinya)

| Pesan error | Artinya | Solusi |
|---|---|---|
| `fatal: not a git repository` | Anda menjalankan perintah di folder yang salah | `cd` ke folder `floki-agent-team` (yang berisi `README.md`), lalu ulangi |
| `remote origin already exists` | Remote sudah pernah disetel | `git remote set-url origin https://github.com/USERNAME/REPO.git` |
| `Authentication failed` / `Support for password authentication was removed` | Anda memakai password akun | Pakai PAT (Jalur B3 Opsi 1) atau SSH (Opsi 2) |
| `Permission denied (publickey)` | SSH key belum terdaftar di GitHub | Ulangi Opsi 2, pastikan key yang ditempel isi `id_ed25519.pub` (bukan yang tanpa `.pub`) |
| `error: remote origin already has ...` / `Updates were rejected because the remote contains work you do not have` | Repo GitHub tidak kosong (misal Anda centang "Add a README") | `git pull --rebase origin main` lalu `git push -u origin main`. Atau paling bersih: hapus repo di GitHub, buat ulang **tanpa** centang apa pun |
| `src refspec main does not match any` | Belum ada commit sama sekali | `git add .` lalu `git commit -m "init"` dulu, baru push |
| `failed to push some refs` + `master` vs `main` | Branch lokal bernama `master`, GitHub pakai `main` | `git branch -M main` lalu `git push -u origin main` |
| `GH001: Large files detected` | File > 100 MB (misal zip ikut ke-commit) | Jangan commit `*.zip`. Kalau sudah terlanjur: `git rm --cached file.zip`, commit, push ulang |
| `LF will be replaced by CRLF` (Windows) | Peringatan line-ending, bukan error | Aman diabaikan, atau `git config --global core.autocrlf true` |
| `nothing to commit, working tree clean` | Semua sudah ter-commit | Normal — langsung lanjut ke `git remote add` / `git push` |

---

## 7. Verifikasi: repo Anda benar

Jalankan di folder proyek lokal:

```bash
git log --oneline          # harus ada minimal 1 commit
git remote -v              # origin menunjuk ke repo Anda
git status                 # "working tree clean"
git ls-files | wc -l       # jumlah file yang terlacak (proyek ini: ~18)
```

Dan yang paling penting — cek **apa yang TIDAK** ikut:

```bash
git ls-files | grep -E "\.env|state/|outputs/|\.key|\.zip"
```

Kalau perintah itu mengeluarkan **apa pun**, ada yang salah: periksa `.gitignore`, lalu `git rm --cached <file>`.

Setelah itu buka `https://github.com/USERNAME/floki-agent-team` di browser. Anda harus melihat `README.md` ter-render, folder `engine/`, `data/`, `web/`, dan badge **Private** di sebelah nama repo.

---

## 8. Setelah repo ada — apa yang jadi mungkin

| Mau apa | Caranya |
|---|---|
| Konten tergenerate tiap 6 jam tanpa server | GitHub Actions menjalankan `python3 -m engine.orchestrator`, lalu commit `outputs/queue.jsonl` |
| Review konten lewat Pull Request | Agent membuka PR berisi item baru; `VIGIL` berperan sebagai CI check; approve = merge |
| Dashboard online 24 jam | Repo ini butuh proses hidup, bukan static. Railway / Fly.io / Render cocok; entrypoint sudah ada di `run.sh` |
| Kolaborator ikut menyetujui copy | Undang di **Settings → Collaborators**, atau lewat Notion (satu-satunya konektor yang tersedia di sesi Arena ini) |

Untuk workflow Actions dan review ala-PR, saya bisa buatkan file `.github/workflows/*.yml`-nya — itu bagian yang tidak butuh kredensial GitHub Anda.

---

## Ringkasan satu layar

```bash
# 1. buat repo KOSONG & PRIVATE di github.com/new  (tanpa README/gitignore/license)
# 2. di folder proyek:
git init -b main
git add .
git commit -m "feat: FLOKI agent team"
git remote add origin https://github.com/USERNAME/floki-agent-team.git
git push -u origin main        # username + PAT sebagai password
# 3. Settings → pastikan Private
```

_Butuh bantuan di langkah tertentu? Sebutkan OS Anda (Windows/macOS/Linux) dan pesan error persis yang muncul — saya sesuaikan instruksinya._
