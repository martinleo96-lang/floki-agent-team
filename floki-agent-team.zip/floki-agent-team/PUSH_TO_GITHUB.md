# Push project ini ke GitHub

Arena **tidak punya konektor GitHub** di sesi ini (`unsupported`), jadi saya tidak
bisa menyambungkan akun Anda langsung. Yang saya siapkan: folder ini sudah
"repo-ready" — `.gitignore` sudah benar, tidak ada file runtime atau secret yang
ikut. Anda tinggal push dari komputer Anda dalam 3 perintah.

---

## Cara 1 — repo baru (paling cepat)

1. Buka https://github.com/new → nama repo, misal `floki-agent-team` → **Create repository**
   (jangan centang "Add a README", biar tidak konflik).
2. Download folder `floki-agent-team` dari workspace ini (atau `floki-agent-team.zip`).
3. Di terminal, dari dalam folder itu:

```bash
git init -b main
git add .
git commit -m "feat: FLOKI agent team — autonomous promo engine (8 agents, VIGIL compliance guard)"
git remote add origin https://github.com/USERNAME/floki-agent-team.git
git push -u origin main
```

Selesai. Repo langsung berisi kode + data fakta + dashboard, tanpa `state/`
dan `outputs/` (memang sengaja di-ignore karena itu hasil runtime Anda).

## Cara 2 — sudah punya repo

```bash
cd floki-agent-team
git init -b main
git add .
git commit -m "feat: FLOKI agent team"
git remote add origin https://github.com/USERNAME/NAMA-REPO.git
git pull --rebase origin main   # kalau repo sudah ada isinya
git push -u origin main
```

---

## Hal yang perlu Anda tahu sebelum push

**Repo privat, bukan publik.** Folder ini berisi strategi kampanye, aturan
compliance, dan knowledge base yang Anda kurasi. Kalau dibuka publik, orang lain
(pesaing, atau lebih buruk: pemburu scam yang mau membalik narasi Anda) bisa
melihat seluruh playbook. Untuk kerja internal: **Settings → General →
Danger Zone → Change visibility → Private.**

**Jangan pernah commit `.env`.** Sudah di-ignore, tapi kalau nanti Anda menambah
`TELEGRAM_BOT_TOKEN` dan sejenisnya, simpan di `.env` lokal — bukan di kode.
Kalau token pernah ikut ke-commit, hapus dan **revoke** tokennya; menghapus file
di commit berikutnya tidak menghilangkan jejaknya di histori.

**Jangan pakai Personal Access Token di URL.** `https://TOKEN@github.com/...`
tercetak di `.git/config` dan gampang bocor. Pakai `gh auth login` atau
credential helper OS Anda.

---

## Setelah di GitHub, ini yang jadi mungkin

| Mau apa | Caranya |
|---|---|
| Auto-regenerate konten tiap 6 jam | GitHub Actions: jalankan `python3 -m engine.orchestrator` sekali (mode batch), commit `outputs/queue.jsonl` |
| Review konten lewat Pull Request | Bot agent buka PR berisi item baru; Anda approve = merge. `VIGIL` = CI check |
| Kolaborator ikut approve | Pakai Notion (satu-satunya konektor yang tersedia di sesi ini) atau review di PR |
| Deploy dashboard online | Repo ini butuh proses yang hidup terus (bukan static). Railway/Fly.io/Render cocok, `run.sh` sudah jadi entrypoint |

Kalau mau saya siapkan salah satunya — misalnya workflow GitHub Actions yang
menggenerasi kalender konten 30 hari otomatis dan commit hasilnya — bilang saja,
saya buatkan file `.github/workflows/*.yml`-nya sekarang. Itu bagian yang
realistis dikerjakan tanpa kredensial GitHub Anda.
