# Cara membuat repo baru di GitHub

Panduan satu halaman. Khusus langkah **membuat repo** saja — push & autentikasi
ada di `PANDUAN_BUAT_REPO.md`.

Akun Anda: **martinleo96-lang**

---

## Cara tercepat: 5 klik

1. Login ke https://github.com
2. Klik **foto profil** Anda di kanan atas → pilih **Your repositories**
3. Di halaman itu, klik tombol hijau **New** (kanan atas)
   — atau langsung buka: https://github.com/new
4. Isi form (lihat tabel di bawah), pilih **Private**
5. Klik tombol hijau **Create repository** di bagian bawah form

Selesai. Repo sudah ada — walaupun masih kosong.

---

## Isi form-nya apa saja

| Field | Isi | Wajib? |
|---|---|---|
| **Owner** | `martinleo96-lang` (biarkan default) | otomatis |
| **Repository name** | `floki-agent-team` | wajib |
| **Description** | `Autonomous FLOKI promo agent team — 8 agents, compliance guard, 6 channels` | opsional, tapi isi saja |
| **Public / Private** | pilih **Private** | **penting** |
| **Add a README file** | **jangan** dicentang | lihat catatan 1 |
| **Add .gitignore** | **jangan** dicentang (proyek ini sudah punya sendiri) | lihat catatan 1 |
| **Choose a license** | **None** | opsional, bisa ditambah nanti |

Catatan nama repo: hanya huruf, angka, `-`, `_`, dan `.`. **Tanpa spasi.**

---

## Catatan 1 — kenapa tiga centang itu harus kosong

Kalau salah satu dicentang, GitHub langsung membuat repo **yang sudah berisi
commit** (README / .gitignore / license). Akibatnya, saat Anda push proyek dari
komputer, git akan menolak dengan pesan:

```
! [rejected] main -> main (fetch first)
error: failed to push some refs
```

Bukan error fatal, tapi bikin bingung. Dua solusi:

- **Paling bersih:** hapus repo itu (cara di bawah), buat ulang **tanpa** centang apa pun.
- **Kalau terlanjur:** `git pull --rebase origin main` lalu `git push -u origin main`.

---

## Setelah klik Create — apa yang Anda lihat

Anda akan diarahkan ke halaman **"Quick setup — if you've done this kind of thing
before"** berisi perintah `git remote add origin ...`.

**Jangan ikuti perintah di halaman itu.** Halaman tersebut mengasumsikan Anda
sudah punya repo git lokal yang terhubung. Untuk proyek ini, urutan yang benar:

```bash
cd path/ke/floki-agent-team
git init -b main
git add .
git commit -m "feat: FLOKI agent team"
git remote add origin https://github.com/martinleo96-lang/floki-agent-team.git
git push -u origin main
```

Atau satu perintah lewat skrip:

```bash
./scripts/init_repo.sh https://github.com/martinleo96-lang/floki-agent-team.git
```

---

## Cara lewat terminal (tanpa browser sama sekali)

Prasyarat: GitHub CLI terpasang (`gh --version`), lalu login sekali:

```bash
gh auth login          # pilih GitHub.com → HTTPS → Login with a web browser
```

Lalu dari dalam folder proyek:

```bash
git init -b main
git add .
git commit -m "feat: FLOKI agent team"
gh repo create floki-agent-team --private --source=. --remote=origin --push
```

Satu perintah terakhir membuat repo **dan** push sekaligus. Tidak perlu buka
github.com sama sekali.

---

## Kalau salah buat (nama keliru, terlanjur publik, dsb.)

Repo boleh dihapus dan dibuat ulang kapan saja:

1. Buka `https://github.com/martinleo96-lang/NAMA-REPO/settings`
2. Scroll paling bawah ke **Danger Zone**
3. Klik **Delete this repository**
4. Ketik nama repo lengkap untuk konfirmasi → hapus

File di komputer Anda **tidak** terpengaruh.

---

## Jebakan yang sering terjadi

| Situasi | Penjelasan |
|---|---|
| `Name already exists on this account` | Anda sudah punya repo dengan nama itu. Pakai nama lain (`floki-agent-team-2026`) atau hapus yang lama. |
| Tombol **New** tidak ketemu | Buka langsung https://github.com/new — selalu berfungsi. |
| Tidak ada pilihan **Private** | Muncul dialog verifikasi. Private repo gratis dan tak terbatas sejak 2020; biasanya cukup verifikasi email. |
| Repo jadi, tapi kosong dan bingung | Normal. Repo kosong hanya berisi instruksi setup — isinya baru ada setelah Anda push. |
| Ingin repo kosong tapi tidak bisa push | Cek nama branch: `git branch -M main` (GitHub pakai `main`, bukan `master`). |

---

## Tanda repo baru Anda sudah benar

- URL `https://github.com/martinleo96-lang/floki-agent-team` bisa dibuka (tidak 404)
- Ada label **Private** di samping nama repo
- Halaman repo masih menampilkan instruksi setup (belum ada file) — **itu wajar**
- Setelah push: `README.md` ter-render, ada folder `engine/`, `data/`, `web/`

Kalau sudah sampai sini, lanjutkan ke `PANDUAN_BUAT_REPO.md` bagian **Jalur B3**
untuk autentikasi (Personal Access Token / SSH) — itu satu-satunya bagian yang
tersisa.
