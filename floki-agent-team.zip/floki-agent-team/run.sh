#!/usr/bin/env bash
# FLOKI Agent Team — start mission control
set -e
cd "$(dirname "$0")"
PORT=${PORT:-8080}
echo "→ starting FLOKI agent team on port $PORT"
exec python3 -m engine.server
